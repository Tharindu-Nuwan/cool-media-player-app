#!/usr/bin/bash

./out/app-jre/bin/java -jar out/cool-media-player.jar